# Hundägar‑schemat (PWA) – GitHub Pages

Detta paket är för **GitHub Pages**. Ditt användarnamn: **ysp8011**. Förslag på repo: **hundagar**.  
När klart blir din URL: **https://ysp8011.github.io/hundagar/**

## Snabb publicering ( via webben )
1. Logga in på GitHub → **New repository** → namn: `hundagar` (Public).
2. Ladda upp *alla filer i den här mappen* (inklusive `index.html`, `service-worker.js`, `.nojekyll`).
3. Gå till **Settings → Pages**. Under *Build and deployment*:  
   - **Source**: Deploy from a branch  
   - **Branch**: `main` (root `/`)  
   - **Save**
4. Vänta ~1 minut. Öppna **https://ysp8011.github.io/hundagar/**.
5. I Safari/Chrome: **Lägg till på hemskärmen / Installera**.

## Alternativ med Git
```bash
git clone https://github.com/ysp8011/hundagar.git
cd hundagar
# Kopiera in ALLA filer från denna zip till mappen
git add .
git commit -m "Initial commit (PWA)"
git push
# Aktivera Pages: Settings → Pages → Deploy from a branch → main / (root)
```

## Tips
- Om sidan laddas utan PWA-funktioner, gör en hård omladdning.  
- `404.html` och `.nojekyll` är med för att GitHub Pages inte ska strula med PWA/SW.  
- För **bakgrundslarm** även när appen är stängd: Exportera **.ics** till din kalender.
