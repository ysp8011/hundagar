// GitHub Pages build: weekly schedule + timer + .ics export
const DEFAULT_WEEKLY = {
  "1": [
    {
      "start": "06:30",
      "end": "07:00",
      "title": "Morgonpromenad med hund",
      "details": "Vatten + ev. kaffe, ta Escitalopram & Lamotrigin",
      "tags": "Promenad, Medicin"
    },
    {
      "start": "07:00",
      "end": "08:00",
      "title": "Uppvakning & lätt aktivitet (mata hunden, hushåll)",
      "details": "Liten frukt",
      "tags": "Rutin"
    },
    {
      "start": "08:00",
      "end": "08:30",
      "title": "Morgonljus & kort rastning",
      "details": "—",
      "tags": "Ljus, Promenad"
    },
    {
      "start": "08:30",
      "end": "12:30",
      "title": "Fokuserat arbete",
      "details": "Vatten/koffein vid behov",
      "tags": "Fokus"
    },
    {
      "start": "12:30",
      "end": "12:50",
      "title": "Lunch",
      "details": "Lax/kyckling + sötpotatis/quinoa + grönsaker + olivolja",
      "tags": "Kost"
    },
    {
      "start": "12:50",
      "end": "13:10",
      "title": "Långpromenad med hund",
      "details": "—",
      "tags": "Promenad"
    },
    {
      "start": "13:10",
      "end": "16:30",
      "title": "Fokuserat arbete",
      "details": "Vatten",
      "tags": "Fokus"
    },
    {
      "start": "16:30",
      "end": "16:50",
      "title": "Kort promenad/lek med hund",
      "details": "Frukt + nötter",
      "tags": "Promenad, Kost"
    },
    {
      "start": "16:50",
      "end": "18:30",
      "title": "Fokuserat arbete",
      "details": "—",
      "tags": "Fokus"
    },
    {
      "start": "18:30",
      "end": "21:30",
      "title": "Styrketräning",
      "details": "Vatten under passet",
      "tags": "Träning"
    },
    {
      "start": "21:30",
      "end": "22:00",
      "title": "Måltid efter gym",
      "details": "Ägg, kalkon, grönsaker, olivolja, havre/bröd",
      "tags": "Kost"
    },
    {
      "start": "22:00",
      "end": "22:15",
      "title": "Kvällspromenad med hund",
      "details": "—",
      "tags": "Promenad"
    }
  ],
  "2": [
    {
      "start": "06:30",
      "end": "07:00",
      "title": "Morgonpromenad med hund",
      "details": "Vatten + ev. kaffe, ta Escitalopram & Lamotrigin",
      "tags": "Promenad, Medicin"
    },
    {
      "start": "07:00",
      "end": "08:00",
      "title": "Uppvakning & lätt aktivitet (mata hunden, hushåll)",
      "details": "Liten frukt",
      "tags": "Rutin"
    },
    {
      "start": "08:00",
      "end": "08:30",
      "title": "Morgonljus & kort rastning",
      "details": "—",
      "tags": "Ljus, Promenad"
    },
    {
      "start": "08:30",
      "end": "12:30",
      "title": "Fokuserat arbete",
      "details": "Vatten/koffein vid behov",
      "tags": "Fokus"
    },
    {
      "start": "12:30",
      "end": "12:50",
      "title": "Lunch",
      "details": "Lax/kyckling + sötpotatis/quinoa + grönsaker + olivolja",
      "tags": "Kost"
    },
    {
      "start": "12:50",
      "end": "13:10",
      "title": "Långpromenad med hund",
      "details": "—",
      "tags": "Promenad"
    },
    {
      "start": "13:10",
      "end": "16:30",
      "title": "Fokuserat arbete",
      "details": "Vatten",
      "tags": "Fokus"
    },
    {
      "start": "16:30",
      "end": "16:50",
      "title": "Kort promenad/lek med hund",
      "details": "Frukt + nötter",
      "tags": "Promenad, Kost"
    },
    {
      "start": "16:50",
      "end": "18:30",
      "title": "Fokuserat arbete",
      "details": "—",
      "tags": "Fokus"
    },
    {
      "start": "18:30",
      "end": "21:30",
      "title": "Styrketräning",
      "details": "Vatten under passet",
      "tags": "Träning"
    },
    {
      "start": "21:30",
      "end": "22:00",
      "title": "Måltid efter gym",
      "details": "Ägg, kalkon, grönsaker, olivolja, havre/bröd",
      "tags": "Kost"
    },
    {
      "start": "22:00",
      "end": "22:15",
      "title": "Kvällspromenad med hund",
      "details": "—",
      "tags": "Promenad"
    }
  ],
  "3": [
    {
      "start": "06:30",
      "end": "07:00",
      "title": "Morgonpromenad med hund",
      "details": "Vatten + ev. kaffe, ta Escitalopram & Lamotrigin",
      "tags": "Promenad, Medicin"
    },
    {
      "start": "07:00",
      "end": "08:00",
      "title": "Uppvakning & lätt aktivitet (mata hunden, hushåll)",
      "details": "Liten frukt",
      "tags": "Rutin"
    },
    {
      "start": "08:00",
      "end": "08:30",
      "title": "Morgonljus & kort rastning",
      "details": "—",
      "tags": "Ljus, Promenad"
    },
    {
      "start": "08:30",
      "end": "12:30",
      "title": "Fokuserat arbete",
      "details": "Vatten/koffein vid behov",
      "tags": "Fokus"
    },
    {
      "start": "12:30",
      "end": "12:50",
      "title": "Lunch",
      "details": "Lax/kyckling + sötpotatis/quinoa + grönsaker + olivolja",
      "tags": "Kost"
    },
    {
      "start": "12:50",
      "end": "13:10",
      "title": "Långpromenad med hund",
      "details": "—",
      "tags": "Promenad"
    },
    {
      "start": "13:10",
      "end": "16:30",
      "title": "Fokuserat arbete",
      "details": "Vatten",
      "tags": "Fokus"
    },
    {
      "start": "16:30",
      "end": "16:50",
      "title": "Kort promenad/lek med hund",
      "details": "Frukt + nötter",
      "tags": "Promenad, Kost"
    },
    {
      "start": "16:50",
      "end": "18:30",
      "title": "Fokuserat arbete",
      "details": "—",
      "tags": "Fokus"
    },
    {
      "start": "18:30",
      "end": "21:30",
      "title": "Styrketräning",
      "details": "Vatten under passet",
      "tags": "Träning"
    },
    {
      "start": "21:30",
      "end": "22:00",
      "title": "Måltid efter gym",
      "details": "Ägg, kalkon, grönsaker, olivolja, havre/bröd",
      "tags": "Kost"
    },
    {
      "start": "22:00",
      "end": "22:15",
      "title": "Kvällspromenad med hund",
      "details": "—",
      "tags": "Promenad"
    }
  ],
  "4": [
    {
      "start": "06:30",
      "end": "07:00",
      "title": "Morgonpromenad med hund",
      "details": "Vatten + ev. kaffe, ta Escitalopram & Lamotrigin",
      "tags": "Promenad, Medicin"
    },
    {
      "start": "07:00",
      "end": "08:00",
      "title": "Uppvakning & lätt aktivitet (mata hunden, hushåll)",
      "details": "Liten frukt",
      "tags": "Rutin"
    },
    {
      "start": "08:00",
      "end": "08:30",
      "title": "Morgonljus & kort rastning",
      "details": "—",
      "tags": "Ljus, Promenad"
    },
    {
      "start": "08:30",
      "end": "12:30",
      "title": "Fokuserat arbete",
      "details": "Vatten/koffein vid behov",
      "tags": "Fokus"
    },
    {
      "start": "12:30",
      "end": "12:50",
      "title": "Lunch",
      "details": "Lax/kyckling + sötpotatis/quinoa + grönsaker + olivolja",
      "tags": "Kost"
    },
    {
      "start": "12:50",
      "end": "13:10",
      "title": "Långpromenad med hund",
      "details": "—",
      "tags": "Promenad"
    },
    {
      "start": "13:10",
      "end": "16:30",
      "title": "Fokuserat arbete",
      "details": "Vatten",
      "tags": "Fokus"
    },
    {
      "start": "16:30",
      "end": "16:50",
      "title": "Kort promenad/lek med hund",
      "details": "Frukt + nötter",
      "tags": "Promenad, Kost"
    },
    {
      "start": "16:50",
      "end": "18:30",
      "title": "Fokuserat arbete",
      "details": "—",
      "tags": "Fokus"
    },
    {
      "start": "18:30",
      "end": "21:30",
      "title": "Styrketräning",
      "details": "Vatten under passet",
      "tags": "Träning"
    },
    {
      "start": "21:30",
      "end": "22:00",
      "title": "Måltid efter gym",
      "details": "Ägg, kalkon, grönsaker, olivolja, havre/bröd",
      "tags": "Kost"
    },
    {
      "start": "22:00",
      "end": "22:15",
      "title": "Kvällspromenad med hund",
      "details": "—",
      "tags": "Promenad"
    }
  ],
  "5": [
    {
      "start": "06:30",
      "end": "07:00",
      "title": "Morgonpromenad med hund",
      "details": "Vatten + ev. kaffe, ta Escitalopram & Lamotrigin",
      "tags": "Promenad, Medicin"
    },
    {
      "start": "07:00",
      "end": "08:00",
      "title": "Uppvakning & lätt aktivitet (mata hunden, hushåll)",
      "details": "Liten frukt",
      "tags": "Rutin"
    },
    {
      "start": "08:00",
      "end": "08:30",
      "title": "Morgonljus & kort rastning",
      "details": "—",
      "tags": "Ljus, Promenad"
    },
    {
      "start": "08:30",
      "end": "12:30",
      "title": "Fokuserat arbete",
      "details": "Vatten/koffein vid behov",
      "tags": "Fokus"
    },
    {
      "start": "12:30",
      "end": "12:50",
      "title": "Lunch",
      "details": "Lax/kyckling + sötpotatis/quinoa + grönsaker + olivolja",
      "tags": "Kost"
    },
    {
      "start": "12:50",
      "end": "13:10",
      "title": "Långpromenad med hund",
      "details": "—",
      "tags": "Promenad"
    },
    {
      "start": "13:10",
      "end": "16:30",
      "title": "Fokuserat arbete",
      "details": "Vatten",
      "tags": "Fokus"
    },
    {
      "start": "16:30",
      "end": "16:50",
      "title": "Kort promenad/lek med hund",
      "details": "Frukt + nötter",
      "tags": "Promenad, Kost"
    },
    {
      "start": "16:50",
      "end": "18:30",
      "title": "Fokuserat arbete",
      "details": "—",
      "tags": "Fokus"
    },
    {
      "start": "18:30",
      "end": "21:30",
      "title": "Styrketräning",
      "details": "Vatten under passet",
      "tags": "Träning"
    },
    {
      "start": "21:30",
      "end": "22:00",
      "title": "Måltid efter gym",
      "details": "Ägg, kalkon, grönsaker, olivolja, havre/bröd",
      "tags": "Kost"
    },
    {
      "start": "22:00",
      "end": "22:15",
      "title": "Kvällspromenad med hund",
      "details": "—",
      "tags": "Promenad"
    }
  ],
  "6": [
    {
      "start": "07:30",
      "end": "08:00",
      "title": "Morgonpromenad med hund",
      "details": "Vatten + ev. kaffe, ta Escitalopram & Lamotrigin",
      "tags": "Promenad, Medicin"
    },
    {
      "start": "08:00",
      "end": "09:00",
      "title": "Uppvakning & lätt aktivitet (mata hunden, hushåll)",
      "details": "Liten frukt",
      "tags": "Rutin"
    },
    {
      "start": "09:00",
      "end": "09:30",
      "title": "Morgonljus & kort rastning",
      "details": "—",
      "tags": "Ljus, Promenad"
    },
    {
      "start": "09:30",
      "end": "13:30",
      "title": "Fokuserat arbete",
      "details": "Vatten/koffein vid behov",
      "tags": "Fokus"
    },
    {
      "start": "13:30",
      "end": "13:50",
      "title": "Lunch",
      "details": "Lax/kyckling + sötpotatis/quinoa + grönsaker + olivolja",
      "tags": "Kost"
    },
    {
      "start": "13:50",
      "end": "14:10",
      "title": "Långpromenad med hund",
      "details": "—",
      "tags": "Promenad"
    },
    {
      "start": "14:10",
      "end": "17:30",
      "title": "Fokuserat arbete",
      "details": "Vatten",
      "tags": "Fokus"
    },
    {
      "start": "17:30",
      "end": "17:50",
      "title": "Kort promenad/lek med hund",
      "details": "Frukt + nötter",
      "tags": "Promenad, Kost"
    },
    {
      "start": "17:50",
      "end": "19:30",
      "title": "Fokuserat arbete",
      "details": "—",
      "tags": "Fokus"
    },
    {
      "start": "19:30",
      "end": "22:30",
      "title": "Styrketräning",
      "details": "Vatten under passet",
      "tags": "Träning"
    },
    {
      "start": "22:30",
      "end": "23:00",
      "title": "Måltid efter gym",
      "details": "Ägg, kalkon, grönsaker, olivolja, havre/bröd",
      "tags": "Kost"
    },
    {
      "start": "23:00",
      "end": "23:15",
      "title": "Kvällspromenad med hund",
      "details": "—",
      "tags": "Promenad"
    }
  ],
  "0": [
    {
      "start": "08:00",
      "end": "08:30",
      "title": "Morgonpromenad med hund",
      "details": "Vatten + ev. kaffe, ta Escitalopram & Lamotrigin",
      "tags": "Promenad, Medicin"
    },
    {
      "start": "08:30",
      "end": "09:30",
      "title": "Uppvakning & lätt aktivitet (mata hunden, hushåll)",
      "details": "Liten frukt",
      "tags": "Rutin"
    },
    {
      "start": "09:30",
      "end": "10:00",
      "title": "Morgonljus & kort rastning",
      "details": "—",
      "tags": "Ljus, Promenad"
    },
    {
      "start": "10:00",
      "end": "14:00",
      "title": "Fokuserat arbete",
      "details": "Vatten/koffein vid behov",
      "tags": "Fokus"
    },
    {
      "start": "14:00",
      "end": "14:20",
      "title": "Lunch",
      "details": "Lax/kyckling + sötpotatis/quinoa + grönsaker + olivolja",
      "tags": "Kost"
    },
    {
      "start": "14:20",
      "end": "14:40",
      "title": "Långpromenad med hund",
      "details": "—",
      "tags": "Promenad"
    },
    {
      "start": "14:40",
      "end": "18:00",
      "title": "Fokuserat arbete",
      "details": "Vatten",
      "tags": "Fokus"
    },
    {
      "start": "18:00",
      "end": "18:20",
      "title": "Kort promenad/lek med hund",
      "details": "Frukt + nötter",
      "tags": "Promenad, Kost"
    },
    {
      "start": "18:20",
      "end": "20:00",
      "title": "Fokuserat arbete",
      "details": "—",
      "tags": "Fokus"
    },
    {
      "start": "20:00",
      "end": "23:00",
      "title": "Styrketräning",
      "details": "Vatten under passet",
      "tags": "Träning"
    },
    {
      "start": "23:00",
      "end": "23:30",
      "title": "Måltid efter gym",
      "details": "Ägg, kalkon, grönsaker, olivolja, havre/bröd",
      "tags": "Kost"
    },
    {
      "start": "23:30",
      "end": "23:45",
      "title": "Kvällspromenad med hund",
      "details": "—",
      "tags": "Promenad"
    }
  ]
};

let state = JSON.parse(localStorage.getItem('hund-v5-state') || '{}');
if(!state.weekly) state.weekly = DEFAULT_WEEKLY;
if(state.theme === undefined) state.theme = 'dark';
if(state.autoStart === undefined) state.autoStart = false;
if(state.autoAdvance === undefined) state.autoAdvance = false;
if(state.sound === undefined) state.sound = true;
if(!state.done) state.done = {};
if(state.activeIndex === undefined) state.activeIndex = -1;
if(!state.lastDate) state.lastDate = '';

const $ = s => document.querySelector(s);
const pad = n => String(n).padStart(2,'0');
function todayDate(){ const t=new Date(); return new Date(t.getFullYear(), t.getMonth(), t.getDate()); }
function todayStr(){ const t=new Date(); return t.getFullYear()+'-'+pad(t.getMonth()+1)+'-'+pad(t.getDate()); }
function getDayKey(d=new Date()){ return String(d.getDay()); }
function parseHM(hm){ const [h,m]=hm.split(':').map(Number); return [h,m]; }
function toDate(hm, d=new Date()){ const [h,m] = parseHM(hm); const x = new Date(d.getFullYear(), d.getMonth(), d.getDate(), h, m, 0, 0); return x; }
function fmtHMS(ms){ if(ms<0) ms=0; const s=Math.floor(ms/1000); const h=Math.floor(s/3600), m=Math.floor((s%3600)/60), sec=s%60; return pad(h)+':'+pad(m)+':'+pad(sec); }
function isFocus(it){ return (it.tags||'').toLowerCase().includes('fokus'); }
function save(){ localStorage.setItem('hund-v5-state', JSON.stringify(state)); }

function scheduleForDayKey(key){ return JSON.parse(JSON.stringify(state.weekly[key]||[])); }

function render(){
  document.documentElement.setAttribute('data-theme', state.theme||'dark');
  document.getElementById('autoStartChk').checked = !!state.autoStart;
  document.getElementById('autoAdvanceChk').checked = !!state.autoAdvance;
  document.getElementById('soundChk').checked = !!state.sound;

  const todayKey = getDayKey();
  const schedule = scheduleForDayKey(todayKey);

  const list = document.getElementById('list'); list.innerHTML='';
  let focusMin = 0;
  const now = new Date();
  let currentIdx = -1;
  schedule.forEach((it,i)=>{ if(toDate(it.start)<=now && toDate(it.end)>now) currentIdx=i; });

  const dayStart = schedule[0]?.start||'', dayEnd = schedule[schedule.length-1]?.end||'';
  document.getElementById('todayRange').textContent = dayStart && dayEnd ? ('Idag '+dayStart+'–'+dayEnd) : 'Idag';
  document.getElementById('nowPill').textContent = 'Nu: '+(currentIdx>=0 ? schedule[currentIdx].title : '—');

  schedule.forEach((it, idx)=>{
    const start = toDate(it.start), end = toDate(it.end);
    const durMin = Math.max(0, Math.round((end-start)/60000));
    if(isFocus(it)) focusMin += durMin;

    const card = document.createElement('div'); card.className='card'+((state.activeIndex===idx || idx===currentIdx)?' active':'');
    card.innerHTML = `
      <div class="time">
        <div>${it.start}–${it.end}</div>
        <div class="badge">${durMin} min</div>
      </div>
      <div style="flex:1;">
        <div class="title">${it.title}</div>
        <div class="details">${it.details||''}</div>
      </div>
      <div class="row-right">
        <input type="checkbox" class="check" ${state.done[idx] ? 'checked' : ''} onchange="toggleDone(${idx})">
        <button class="btn" onclick="startActivity(${idx})">Starta</button>
        <button class="btn ghost" onclick="openWeekModal('${todayKey}')">Redigera dagen</button>
      </div>`;
    list.appendChild(card);
  });

  document.getElementById('focusCount').textContent = (focusMin/60).toFixed(2)+' h fokus';
  updateTimerUI();
}

window.toggleDone = i => { state.done[i]=!state.done[i]; save(); render(); };

let countdownEndsAt=null, timer=null;

function updateTimerUI(){
  const clock=document.getElementById('timerClock'), label=document.getElementById('timerLabel');
  if(state.activeIndex<0){ clock.textContent='--:--:--'; label.textContent='Ingen aktivitet startad'; return; }
  const todayKey = getDayKey();
  const schedule = scheduleForDayKey(todayKey);
  const it = schedule[state.activeIndex];
  const remaining = countdownEndsAt ? (countdownEndsAt - new Date()) : (toDate(it.end) - new Date());
  clock.textContent = fmtHMS(remaining);
  label.textContent = it.title + ' ('+it.start+'–'+it.end+')';
}

function startActivity(i){
  const todayKey = getDayKey();
  const schedule = scheduleForDayKey(todayKey);
  state.activeIndex = i; save();
  countdownEndsAt = toDate(schedule[i].end);
  if(timer) clearInterval(timer);
  timer = setInterval(()=>{
    updateTimerUI();
    if(countdownEndsAt - new Date() <= 0){
      clearInterval(timer);
      state.done[i]=true; save(); render();
      if(state.autoAdvance && i < schedule.length-1) startActivity(i+1);
    }
  }, 250);
  render();
}
window.startActivity = startActivity;

// Controls
document.getElementById('startNextBtn').addEventListener('click', ()=>{ const todayKey=getDayKey(); const schedule=scheduleForDayKey(todayKey); const now=new Date(); let next=schedule.findIndex(it => toDate(it.end)>now); if(next<0) next=0; startActivity(next); });
document.getElementById('pauseBtn').addEventListener('click', ()=>{ /* simplified pause removed in GH bundle */ });
document.getElementById('resetTimerBtn').addEventListener('click', ()=>{ state.activeIndex=-1; countdownEndsAt=null; save(); render(); });
document.getElementById('notifBtn').addEventListener('click', async()=>{ if(!('Notification' in window)) return alert('Notiser stöds inte.'); const perm=await Notification.requestPermission(); if(perm==='granted') alert('Notiser aktiverade.'); });
document.getElementById('themeBtn').addEventListener('click', ()=>{ state.theme=(state.theme==='dark'?'light':'dark'); save(); render(); });
document.getElementById('autoStartChk').addEventListener('change', e=>{ state.autoStart=e.target.checked; save(); });
document.getElementById('autoAdvanceChk').addEventListener('change', e=>{ state.autoAdvance=e.target.checked; save(); });
document.getElementById('soundChk').addEventListener('change', e=>{ state.sound=e.target.checked; save(); });
document.getElementById('fsBtn').addEventListener('click', async()=>{ const el=document.getElementById('widgetArea'); if(!document.fullscreenElement){ await el.requestFullscreen().catch(()=>{}); document.body.classList.add('fullscreen'); } else { await document.exitFullscreen(); document.body.classList.remove('fullscreen'); } });
document.getElementById('resetBtn').addEventListener('click', ()=>{ if(confirm('Återställ allt?')){ localStorage.removeItem('hund-v5-state'); state={}; location.reload(); } });

// ICS export (för bakgrundslarm via kalender)
document.getElementById('icsBtn').addEventListener('click', ()=>{ 
  const todayKey=getDayKey(); const schedule=scheduleForDayKey(todayKey);
  const dt=new Date(); const y=dt.getFullYear(), m=dt.getMonth()+1, d=dt.getDate();
  const fmt=(h,mn)=> y+String(m).padStart(2,'0')+String(d).padStart(2,'0')+String(h).padStart(2,'0')+String(mn).padStart(2,'0')+'00';
  let ics='BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//Hundägar-schema//EN\n';
  schedule.forEach((it)=>{ const [sh,sm]=it.start.split(':').map(Number); const [eh,em]=it.end.split(':').map(Number);
    ics+='BEGIN:VEVENT\n'+'UID:'+Math.random().toString(36).slice(2)+'@hundagar\n'+'SUMMARY:'+it.title.replace(/\n/g,' ')+'\n'+'DESCRIPTION:'+(it.details||'').replace(/\n/g,' ')+'\n'+'DTSTART:'+fmt(sh,sm)+'\n'+'DTEND:'+fmt(eh,em)+'\n'+'BEGIN:VALARM\nACTION:DISPLAY\nDESCRIPTION:Snart dags (10 min)\nTRIGGER:-PT10M\nEND:VALARM\n'+'BEGIN:VALARM\nACTION:DISPLAY\nDESCRIPTION:Start nu\nTRIGGER:PT0M\nEND:VALARM\n'+'END:VEVENT\n'; });
  ics+='END:VCALENDAR';
  const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([ics],{type:'text/calendar'})); a.download='hundagar-idag.ics'; a.click();
});

// Weekly editor (minimal)
function openWeekModal(dayKey){
  const modal=document.getElementById('weekModal'); modal.classList.remove('hidden');
  renderWeekList(dayKey);
  modal.dataset.dayKey = dayKey;
}
window.openWeekModal = openWeekModal;

function renderWeekList(dayKey){
  const cont=document.getElementById('weekList'); cont.innerHTML='';
  const items=state.weekly[dayKey]||[];
  items.forEach((it, idx)=>{
    const row=document.createElement('div'); row.className='row';
    row.innerHTML = `
      <input type="time" value="${it.start}" data-idx="${idx}" data-field="start">
      <input type="time" value="${it.end}" data-idx="${idx}" data-field="end">
      <input type="text" value="${it.title}" data-idx="${idx}" data-field="title">
      <input type="text" value="${it.details||''}" data-idx="${idx}" data-field="details">
      <input type="text" value="${it.tags||''}" data-idx="${idx}" data-field="tags">
      <button class="del" data-del="${idx}">Ta bort</button>`;
    cont.appendChild(row);
  });
  cont.querySelectorAll('input').forEach(inp=>{ inp.addEventListener('change', ev=>{ const i=+ev.target.dataset.idx; const f=ev.target.dataset.field; state.weekly[dayKey][i][f]=ev.target.value; save(); }); });
  cont.querySelectorAll('[data-del]').forEach(btn=>btn.addEventListener('click', ev=>{ const i=+ev.target.dataset.del; state.weekly[dayKey].splice(i,1); save(); renderWeekList(dayKey); }));
}

document.getElementById('weekBtn').addEventListener('click', ()=>openWeekModal(getDayKey()));
document.getElementById('closeWeek').addEventListener('click', ()=>document.getElementById('weekModal').classList.add('hidden'));
document.getElementById('addSlot').addEventListener('click', ()=>{ const key=document.getElementById('weekModal').dataset.dayKey; (state.weekly[key]=state.weekly[key]||[]).push({start:'10:00', end:'10:30', title:'Ny aktivitet', details:'', tags:''}); save(); renderWeekList(key); });

// Install + SW
let installPrompt=null;
window.addEventListener('beforeinstallprompt', (e)=>{ installPrompt=e; document.getElementById('installBtn').disabled=false; });
document.getElementById('installBtn').addEventListener('click', async()=>{ if(!installPrompt) return; installPrompt.prompt(); installPrompt=null; });
if('serviceWorker' in navigator) navigator.serviceWorker.register('service-worker.js');

render();
